#!/bin/bash

ADDONS_DIR="/Applications/Blender.app/Contents/Resources/3.0/scripts/addons"
ln -s "$(pwd)" "$ADDONS_DIR/diffgrowth"
